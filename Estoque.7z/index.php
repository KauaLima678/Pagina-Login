<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/index.css">
</head>
<body>
    <section class="login">
        <div class="card-login">
        <form action="" method="POST">
      <h2>Login</h2>
      <input type="text" id="nome" name="nome"  placeholder="Digite seu Nome" required><br>
      <input type="text" id="email" name="email" placeholder="Digite seu email" required><br>
      <input type="password" id="senha" name="senha"  placeholder="Digite sua senha" required><br>


      <input class="button" type="submit" value="Cadastrar">
      <p>Não possui uma conta? <br>
      <a class="cadastro" href="cadastro.php"><span></span>Ir para cadastro</a></p>
    </form>
        </div>
    </section>
</body>
</html>